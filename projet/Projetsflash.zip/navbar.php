<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <link rel="stylesheet" href="asset/css/navbar.css">
    <link rel="shortcut icon" href="asset/images/favicon.png" type="image/x-icon">
</head>
<body>
    

<header class="header">
    <nav class="navbar">
    <img src="asset/images/logo.webp" alt="image_logo à définir" width="100" height="100"/>
        <ol>
            <li class="list-nav">
        <a href="accueil.html" class="nav-link"> Accueil </a>
        </li>
        <li class="list-nav">
        <a href="scores.html" class="nav-link"> Scores </a>
        </li>
         <li class="list-nav">
        <a class="colored-btn-nav nav-link" href="Nous_contacter.html"> Nous contacter </a>
        </li>
        </ol>
    </nav>
</header>












<footer class="footer-container">
    <div class="footer">
<div class="one" ><img src="/asset/images/logo.webp" alt="">
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse scelerisque in tortor vitae sollicitudin. </p>
</div>
<div class="two"><span>Menu</span>
<a href="">Accueil</a>
<a href="">Scores</a>
<a href="">Contact</a></div>
<div class="three"><span>Contact-nous</span>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
<a href="mailto:contact@web.com">contact@web.com</a></div>
<div class="four">
    <div class="social-row">
        <a href=""><img src="asset/images/facebook-circle-fill.svg" alt=""></a>
        <a href=""><img src="asset/images/instagram-fill.svg" alt=""></a>
        <a href=""><img src="asset/images/linkedin-fill.svg" alt=""></a>
        <a href=""><img src="asset/images/twitter-fill.svg" alt=""></a>
    </div>
</div>


</footer>
<hr>
<div class="mention">
    <p>Copyright © 2025 <img src="asset/images/logo.webp" width="30" alt="Logo"> - All rights reserved</p>
</div>
</body>
</html>